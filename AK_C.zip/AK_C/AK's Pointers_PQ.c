//Q-1
#include <stdio.h>
int main()
{
    int m=10,n,o, *z;
    z=&m;
    printf("Value of m=%d\n", *z);
    printf("Value of m=%d\n",m);
    printf("Value of z=%d\n",z);
    printf("Address of m=%u\n",z);
    printf("Address of m=%u\n",&m);
    printf("Address of z=%u\n",&z);
    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
    int a=12, *b;
    b=&a;
    printf("address of a=%u\n",&a);
    printf("address of a=%u\n",b);
    printf("value of a=%d\n",a);
    printf("value of a=%d\n", *b);
    return 0;

}
//Q-4
#include <stdio.h>
int main()
{
    int a=2,b=2, *aa, *bb,sum;
    aa=&a;
    bb=&b;
    sum= *aa+ *bb;
    printf("The sum of value a and b=%d\n",sum);
    return 0;
}
//Q-5
#include <stdio.h>
int cal(int *a,int *b)
{
    int *sum;
    sum= *a+ *b;
    return sum;
}
int main()
{
    int sum,a,b;
    printf("Enter the value of a:");
    scanf("%d\n",&a);
    printf("Enter the value of b:");
    scanf("%d\n",&b);
    sum=cal(&a,&b);
    printf("The sum of a and b is=%d\n",sum);
    return 0;
}
//Q-6
#include <stdio.h>
int main()
{
    int *z, *x;
    int a,b;

    printf("Enter first number");
    scanf("%d\n",&a);
    printf("Enter second number");
    scanf("%d\n",&b);
    printf("\n");
    z=&a; x=&b;
    if(z<x)
        printf("First number is greater");
    else
        printf("Second number is greater");

    return 0;
}
//Q-7
#include <stdio.h>
int main()
{
    int a[10];
    int i,j;

    printf("enter the 10 elements you want to store");
    for(i=0;i<=10;i++)
    {
        scanf("%d\n",a+i);
    }
    for (j=0;j<=10;j++)
        printf("the elements are=%d\n", *(a+j));

    return 0;
}
//Q-11
#include <stdio.h>
void func(int *n1,int *n2,int *n3)
{
    int i= *n1;
    *n1= *n2;
    *n2= *n3;
    *n3= i;

}
int main()
{
    int n1,n2,n3;

    printf("Enter the number n1");
    scanf("%d\n",&n1);
    printf("Enter the number n2");
    scanf("%d\n",&n2);
    printf("Enter the number n3");
    scanf("%d\n",&n3);

    func(&n1,&n2,&n3);

    printf("The elements were:\n");
    printf("%d\n%d\n%d\n",n1,n2,n3);

    return 0;

}
//Q-9
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n;
    int *num,i;

    printf("Enter the number of elements you want to store");
    scanf("%d\n",&n);
    num=(int *)calloc(n,sizeof(int));
    if(num==NULL)
    {
        printf("No memmory is allocated");
        exit(0);
    }

    for(i=0;i<=n;i++)
    {
        printf("Enter the numbers you want to store");
        scanf("%d\n",num+i);
    }
    for(i=1;i<n;i++)
    {
        if( *num> *(num+i))
            *num= *(num+i);
    }
    printf("The largest number is=%d\n", *num);
    return 0;

}
//Q-12
#include <stdio.h>
void fact(int num,int *f)
{
    int i;
  //  int*f=1;
    for(i=1;i<= num;i++)
    {
        *f= *f *i;
    }
 //   return *f;
}
int main()
{
    int num, fac=1;

    printf("Enter the number");
    scanf("%d\n",&num);
    fact(num,&fac);

    printf("The factorial value of%d=%d\n",num, fac);
    return 0;
}
//Q-14
#include <stdio.h>
#include <stdlib.h>
void main()
{
    int n, *ptr,i;

    printf("Enter the size of for array");
    scanf("%d\n",&n);

    ptr=(int *)malloc(n*sizeof(int));

    for(i=0;i<=5;i++)
    {
        ptr[i]=i*i;
        printf("%d\n",ptr[i]);
    }
}
//Q-17
#include <stdio.h>
#define S 5
int main()
{
    int arr[S]={1,2,3,4,5};
    int i, *ptr;

    *ptr=arr[0];
   // p=ptr;

    printf("The reversed order of your input is\n");
    for(i=5;i>=0;i--)
    {
        printf("%d\n", *(ptr+i));
    }
    return 0;
}
//Q-10
#include <stdio.h>
int main()
{
    char ch[100];
    int i,len=1;

    printf("Enter the character:");
    gets(ch);

    for(i=1; ch[i] !='\0';i++)
    {
        len++;
    }
    printf("Character:%s\tLenght:%d\n",ch,len);
    return 0;
}
//Q-13
#include <stdio.h>
int check(char str1)
{
    switch(str1)
    {
        case 'A': return 0; break;
        case 'a': return 0; break;
        case 'E': return 0; break;
        case 'e': return 0; break;
        case 'I': return 0; break;
        case 'i': return 0; break;
        case 'o': return 0; break;
        case 'O': return 0; break;
        case 'U': return 0; break;
        case 'u': return 0; break;
        default:return 1;
    }
}
int main()
{
    char str1[100];
    int i;
    int vow=0,cont=0;

    printf("Enter the sentence:");
    gets(str1);
    printf("\n");

    for(i=0; str1[i] != '\0'; i++)
    {
        if(check(str1[i])==0)
        {
            vow++;
        }
        else if(check(str1[i])==1)
        {
            cont++;
        }
    }
    printf("Sentence:%s\nlenght of vowels=%d\nLenght of constants=%d\n", str1, vow, cont);

    return 0;
}
