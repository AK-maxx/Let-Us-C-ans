//ch-14 ex-1 simple 2-D array 
#include<stdio.h>
void main()
{
	int arr[4][2],i;
	for(i=0;i<=3;i++)
	{
		printf("enter roll no. and marks:");
		scanf("%d%d",&arr[i][0],&arr[i][1]);
	}
	for(i=0;i<=3;i++)
	printf("stud-%d\nroll no.=%d  marks=%d\n",i,arr[i][0],arr[i][1]);
}
//ch-14 ex-2 print address of array
#include<stdio.h>
void main()
{
    int arr[4][2]={1234,56,1212,33,1434,80,1312,78},i;
    for(i=0;i<=3;i++)
        printf("address of %dth 1-D array=%u\n",i,arr[i]);
}
//ch-14 ex-3 print array using pointers
#include<stdio.h>
void main()
{
	int i,j,(*p)[2],*pint,arr[4][2]={1234,56,1212,45,1367,67,1489,34};
	for(i=0;i<=3;i++)
	{
		p=&arr[i];
		pint=(int*)p;
		printf("\n");
		for(j=0;j<=1;j++)
            printf("%d "*(pint+j))
	}
}
//ch-14 ex-4 passing 2-D array to a function
#include<stdio.h>
void display(char b[][3] );
void main()
{
	char box[3][3]={201,203,187,204,206,185,200,202,188};
	display(box);
}
void display(char b[][3])
{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=2;j++)
			printf("%c",b[i][j]);
        printf("\n");
	}
}
//ch-14 ex-5 array of pointers
#include<stdio.h>
void main()
{
	int *arr[4],i=31,j=5,k=19,l=71,m;
	arr[0]=&i;   arr[1]=&j;   
	arr[2]=&k;   arr[3]=&l;
	for(m=0;m<=3;m++)
	     printf("%d\n",*(arr[m]));
}