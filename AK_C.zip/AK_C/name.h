void dis_name(char std)
{
    int y,i;
    printf("enter the roll number:");
    scanf("%d\n",&y);
    for(i=0;i<10;i++)
    {
        if((std+i).year==y)
        {
            printf("Name:%s\n",(std+i).name);
            printf("Roll number:%d\n",(std+i).roll_no);
            printf("Department:%s\n",(std+i).dep);
            printf("Course:%s\n",(std+i).course);
            printf("Year:%d\n",(std+i).year);
        }
        else
        continue;
    }
}
