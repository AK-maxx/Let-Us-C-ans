//A
//Q-1
#include <stdio.h>
int main()
{
    printf("Hello World!\n");
    main();
    return 0;
}
//Q-2
#include <stdlib.h>
int  main()
{
    int i=0;
    i++;
    if(i<=5)
    {
        printf("C is a good language for beginners\n");
        exit (0);
        main();
    }
    return 0;
}
//B
//Q-5
#include <stdio.h>
//void fact(int )
void rec(int,int);
int main()
{
    int n,fac,z=2;
    printf("Enter the number=");
    scanf("%d\n",&n);

    fac=rec(n,z);
    printf("The factors are=%d\n",fac);

    return 0;
}
void rec(int n,i)
{
    int z=2;
    if(n<2)
        return 0;
    else if ()
    {
        ;
    }

}
