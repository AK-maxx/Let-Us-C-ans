/*
//Q-6
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit.txt","r");
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    int ch,no=1;
    do
    {
        ch=fgetc(fp);
        if(ch=='\n')
            no++;
        else
            continue;
    }while(ch!=EOF);
    printf("The number of lines=%d\n",no);
    fclose(fp);
}

//Q-7
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit2.txt","r");
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    int ch,noc=1,now=1;
    do
    {
        ch=fgetc(fp);
        noc++;
        if(ch==' ' || ch=='\n')
            now++;
    }while(ch!=EOF);
    printf("Number of characters:%d\n",noc-1);
    printf("Number of words:%d\n",now-1);
    fclose(fp);
}
*/
//Q-8
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp;
    fp=fopen("testdata.txt","w");
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    remove("testdata.txt");
    int i,z;
    char str[4][5]={"Test1","Test2","Test3","Test4"};
    do
   {
        for(i=0;i<4;i++)
        {
           for(z=0;z<5;z++)
            {
                fprintf(fp,"%c",str[i][z]);
            }
            fprintf(fp,"\n");
        }
        fprintf(fp,"\n");
    }while(strlen(str)>0);
    fclose(fp);
}
