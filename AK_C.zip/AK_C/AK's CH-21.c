/*
//~
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    unsigned char ch=63,dh=~ch;
    printf("~ch(63)=%d\n",dh);
    printf("~ch(63)=%X\n",dh);
    printf("~ch(63)=%#X\n",dh);
    printf("~ch(63)=%x\n",dh);
}

//<< >>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void showbits(unsigned char n)
{
    int i;
    unsigned char j,k,andmask;
    for(i=7;i>=0;i--)
    {
        j=i;
        andmask=1<<j;
        k=n&andmask;
        k==0?printf("0"):printf("1");
    }
}
void main()
{
    unsigned char ch=52;
    int k;
    printf("The value is %d\nBinary equivalent:",ch);
    showbits(ch);
    k=ch<<1;
    printf("\n1 Left swift:");
    showbits(k);
    k=ch>>1;
    printf("\n1 Right swift:");
    showbits(k);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BV(x) (1<<x)
void main()
{
    unsigned char a=BV(3);
    printf("a=%02x",a);
}

//&
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void showbits(unsigned char n)
{
    int i;
    unsigned char j,k,andmask;
    for(i=7;i>=0;i--)
    {
        j=i;
        andmask=1<<j;
        k=n&andmask;
        k==0?printf("0"):printf("1");
    }
}
void main()
{
    unsigned char ch=0xAD,j;
    printf("Value:%d\n",ch);
    showbits(ch);

    j=ch & 0x20;
    if(j==0)   printf("\nBit: 5th\nMode: OFF");
    else       printf("\nBit: 5th\nMode: ON");

    j=ch & 0x08;
    if(j==0)   printf("\nBit: 3th\nMode: OFF");
    else
    {
        printf("\nBit: 3th\nMode: ON");
        ch=ch & 0xF7;
        printf("\nBit: ");
        showbits(ch);
        j=ch & 0x08;
        if(j==0)    printf("\nMode: OFF");
    }
}

//|
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void showbits(unsigned char n)
{
    int i;
    unsigned char j,k,andmask;
    for(i=7;i>=0;i--)
    {
        j=i;
        andmask=1<<j;
        k=n&andmask;
        k==0?printf("0"):printf("1");
    }
}
void main()
{
    unsigned char ch=0xAD,j;
    printf("Value:%d\n",ch);
    showbits(ch);

    j=ch | 0x20;
    if(j==0)   printf("\nBit: 5th\nMode: OFF");
    else       printf("\nBit: 5th\nMode: ON");

    j=ch | 0x08;
    if(j==0)   printf("\nBit: 3rd\nMode: OFF");
    else
    {
        printf("\nBit: 3rd\nMode: ON");
        ch=ch | 0xF7;
        printf("\nBit: ");
        showbits(ch);
        j=ch | 0x08;
        if(j==0)    printf("\nMode: OFF");
    }
}
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void showbits(unsigned char n)
{
    int i;
    unsigned char j,k,andmask;
    for(i=7;i>=0;i--)
    {
        j=i;
        andmask=1<<j;
        k=n&andmask;
        k==0?printf("0"):printf("1");
    }
}
void main()
{
    unsigned char ch;
    printf("Enter the number who's binary representation you want to see:");
    scanf("%d\n",ch);
    printf("Number %d\nBinary representation:",ch);
    showbits(ch);
}
