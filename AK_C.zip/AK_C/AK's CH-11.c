//rough practice
#include <stdio.h>
void main()
{
    unsigned int c = 4294967295;
    double a = 2345690976545654565;
    char b = 130;
    printf("%lf\t%d\t%u\n",a,b,c);
}
//plain practice of automatic storage class
#include <stdio.h>
void main()
{
    auto int a=543,s,d,f,g;
    printf("%d\n%d\n%d\n%d\n%d\n",a,s,d,f,g);
}
//Plain practice of register storage class
#include <stdio.h>
void main()
{
    register int a=123,b;
    printf("%d\n%d\n",a,b);
}
//Plain practice of static storage class
#include <stdio.h>
void main()
{
    static int a,b=1234;
    printf("%d\n%d\n",a,b);
}
//Plain practice of External storage class
#include <stdio.h>
int a;
void waste(int);
void main()
{
    printf("enter the number to be experesd in it's cube=");
    scanf("%d\n",&a);
    waste(a);
}
void waste(int a)
{
    int aa=a*a*a;
    printf("the cube of %d is=%d\n",a,aa);
}
//A
//Q-1
#include<stdio.h>
int a=0;
void val();
int main()
{
    printf("main's a=%d\n",a);
    a++;
    val();
    printf("main's a=%d\n",a);
    val();
    return 0;
}
void val()
{
    a=100;
    printf("Val's a=%d\n",a);
    a++;
}
//Q-2
#include <stdio.h>
int main()
{
    static int z=5;
    printf("z=%d\n",z--);
    if(z!=0)
        main();
    return 0;
}
//Q-3
#include <stdio.h>
void fun();
int main()
{
    fun();
    fun();

    return 0;
}
void fun()
{
    auto int a=0;
    static int b=0;
    register c=0;
    printf("%d\t%d\t%d\n",a,b,c);

    a++;
    b++;
    c++;
    printf("%d\t%d\t%d\n",a,b,c);
}

//Q-4
#include <stdio.h>
int x=10;
int main()
{
    int x=20;
    {
        int x=30;
        printf("%d\n",x);
    }
    printf("%d\n",x);
    return 0;
}
//B
//Q-1
#include <stdio.h>
int main()
{
    long int num=2;
    printf("%ld\n",num);
    return 0;
}
//Q-2
#include <stdio.h>
int main()
{
    char ch=200;
    printf("%d\n",ch);
    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
    long double a=23.76e456;
    double b=25;
    printf("%lf\t%d\n",a,b);
    return 0;
}
//Q-4
#include <stdio.h>
int y=7;
int main()
{
    int y=8;
    static int z=9;
    printf("%d\t%d\n",y,z);
    return 0;
}

