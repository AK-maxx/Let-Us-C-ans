//H
//Q-1
#include<stdio.h>
int main()
{
	int year;
	printf("Enter the number");
	scanf("%d",&year);
	
    (year%4==0? printf("this is a leap year"):printf("this is'nt a leap year"));	

	return 0;
	
}
//Q-2
#include<stdio.h>
int main ()
{
     int s1,s2,s3;
	 printf("enter the first side the triangle=");
	 scanf("%d",&s1);

	 printf("enter the second side the triangle=");\

	 printf("enter the third side the triangle=");
	 scanf("%d",&s3);

	 if((s1==s2)&&(s2==s3))
	   printf("This is a equilateral triangle");

	 if((s1==s2)||(s1==s3)||(s2==s3))
	   printf("This is a isosceles triangle");

	 if((s1!=s2)&&(s2!=s3)&&(s1!=s3))
	   printf("This is a scalene triangle");

	 if((s1<s3)&&(s2<s3)&&(s1==s2))
	   printf("This is a right angled triangle");

	   return 0;
}
//Q-3
#include<stdio.h>
void main()
{
    char chara;
	printf("enter the character=");
	scanf("%c",&chara);
	
     if(chara>=65&&chara<=90)
        printf("This is a capital character");
     else if (chara>=97&&chara<=122)
        printf("This is a small character");
     else if(chara>=48&&chara<=57)
        printf("This is a number");
     else if ((chara>=0&&chara<=47)||(chara>=58&&chara<=64)||(chara>=91&&chara<=96)||(chara>=123&&chara<=127))
        printf("This is a special symbol");
     	 
}
//Q-4
#include<stdio.h>
int main()
{
	int s1,s2,s3,stot;
	printf("Enter the first side=");
    scanf("%d",&s1);
 	
	printf("Enter the second side=");
    scanf("%d",&s2);
	
	printf("Enter the third side=");
    scanf("%d",&s3);
	
	stot=s1+s2;
	if(stot>s3)
	  printf("This is a valid triangle");
	else
	  printf("This is an invalid triangle");
	  
	return 0;
}