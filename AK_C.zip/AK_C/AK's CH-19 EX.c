/*
//Q-1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fs=fopen("myfile.txt","r");
    if(fs==NULL)
    {
        printf("Error!");
        exit(1);
    }
    int i=1;
    int ch;
    printf("%d.",i++);
    do
    {
        ch=fgetc(fs);
        printf("%c",ch);

        if(ch=='\n')
        {
            printf("%d.",i);
            i++;
        }

    }while(ch!=EOF);
    fclose(fs);
}

//Q-2
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp, *fs;
    fp=fopen("myfile2.txt","a");
    fs=fopen("myfile.txt","r");
    if(fp==NULL)
    {
        printf("Error!(1)");
        exit(1);
    }
    if(fs==NULL)
    {
        printf("Error!(2)");
        fclose(fs);
        exit(2);
    }
    char ch;
    while(1)
    {
        ch=fgetc(fs);
        if(ch==EOF)
            break;
        fputc(ch,fp);
    }
    fclose(fp);
    fclose(fs);
}

//Q-4
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp, *fs;
    fp=fopen("myfile2.txt","a");
    fs=fopen("myfile.txt","r");
    if(fp==NULL)
    {
        printf("Error!(1)");
        exit(1);
    }
    if(fs==NULL)
    {
        printf("Error!(2)");
        fclose(fp);
        exit(2);
    }
    char ch;
    do
    {
        ch=fgetc(fs);
        if(ch>='a' && ch<='z')
            ch=ch-32;
        fputc(ch,fp);
    }while(ch!=EOF);
    fclose(fp);
    fclose(fs);
    FILE *ff=fopen("myfile2.txt","r");
    if(ff==NULL)
    {
        printf("Error!");
        exit(4);
    }
    int chh;
    do
    {
        chh=fgetc(ff);
        printf("%c",chh);
    }while(chh!=EOF);
    fclose(ff);
}

//Q-5
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("myfile.txt","r");
    FILE *fs=fopen("sample.txt","r");
    FILE *fi=fopen("Input2.txt","w");

    if(fp==NULL)
    {
        printf("Error!(1)");
      //  fclose (fp);
        exit(1);
    }
    if(fi==NULL)
    {
        printf("Error!(2)");
        fclose(fi);
        exit(2);
    }
    if(fs==NULL)
    {
        printf("Error!(3)");
        fclose(fs);
        exit(3);
    }
    int ch1[20],ch2[20];
    do
    {
        fgets(ch1,20,fp);
        fputs(ch1,fi);

        fgets(ch2,20,fs);
        fputs(ch2,fi);
    }while(ch1!=EOF,ch2!=EOF);
    fclose(fs);
    fclose(fp);
    fclose(fi);
}
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("test.txt","r"), *fs=fopen("test2.txt","w");
    if(fp==NULL)
    {
        printf("Error!(1)");
        exit(1);
    }
    if(fs==NULL)
    {
        printf("Error!(2)");
        fclose(fp);
        exit(2);
    }
    int ch;
    do
    {
        ch=fgetc(fp);
        if(ch!='t' && ch!='h' && ch!='e' || ch!='T' && ch!='H' && ch!='E')
            fputc(ch,fs);
        if(ch!='a' && ch!='n' || ch!='A' && ch!='N')
            fputc(ch,fs);
        if(ch!='A' || ch!='a')
            fputc(ch,fs);
    }while(ch!=EOF);
    fclose(fs);
    fclose(fp);
}

