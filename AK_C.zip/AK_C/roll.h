void dis_det(char std_name,char std_dep,char std_course,char std_roll_no,char std_year)
{
    int rol,i;
    printf("enter the roll number:");
    scanf("%d\n",&rol);
    for(i=0;i<10;i++)
    {
        if(std_roll_no==rol)
        {
            printf("Name:%s\n",std_name);
            printf("Roll number:%d\n",std_roll_no);
            printf("Department:%s\n",std_dep);
            printf("Course:%s\n",std_course);
            printf("Year:%d\n",std_year);
        }
        else
        continue;
    }
}
