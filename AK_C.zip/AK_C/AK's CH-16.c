#include <stdio.h>
#include <string.h>
#define FND 1
#define NFND 0
int main()
{
    char ch[3][100]={
                        "akassh",
                        "parag",
                        "raman"
                    };
    int i,a,flag;
    char name[100];
    printf("Enter your name:");
    scanf("%s\n",name);
    flag=NFND;
    for(i=0;i<3;i++)
    {
        a=strcmp(&ch[i][0],name);
        if(a==0)
        {
            printf("come in");
            flag=FND;
            break;
        }
        else if(flag==NFND)
        {
            printf("Get out");
            return 0;;
        }
    }
    //return 0;
}
#include <stdio.h>
#include <string.h>
int check(char str1)
{
    switch(str1)
    {
        case 'A': return 0; break;
        case 'a': return 0; break;
        case 'E': return 0; break;
        case 'e': return 0; break;
        case 'I': return 0; break;
        case 'i': return 0; break;
        case 'o': return 0; break;
        case 'O': return 0; break;
        case 'U': return 0; break;
        case 'u': return 0; break;
        default:return 1;
    }
}
int main()
{
    char str1[100],str2[100];
    int i,j;

    printf("Enter the sentence:");
    gets(str1);

    for(i=0,j=0; str1[i] != '\0'; i++,j++)
    {
        if(check(str1[i])==0)
        {
            str2[j]=str1[i];
        }
    }
    str2[j]='\0';
    strcpy(str1,str2);
    printf("The vowel reduced sentence is:%s\n", str1);

    return 0;
}
#include <stdio.h>
#include <string.h>
int main()
{
    int num;
    char wd1[10]={
    };
    int i,n_num=1;
    printf("Enter the number:");
    scanf("%d\n",&num);

    for(i=0;i<=num;i++)
    {
        n_num = num%10;
        n_num++;
    }
    ch[i]='\0';
    printf("Number form:%c\n",ch);
    return 0;
}
