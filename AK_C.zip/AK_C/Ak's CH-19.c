#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    FILE *fp=fopen("sample2.txt","r");
    int noc,not,non,nos,now,nono;
    noc=not=non=nos=now=nono=0;
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    printf("Contents of your file :\n");
    while(1)
    {
        int ch=fgetc(fp);
        if(ch==EOF)
            break;

        noc++;
        if(ch=='\n')
            non++;
        if(ch=='\t')
            not++;
        if(ch==' ')
            nos++;
        if(ch>='a'&&ch<='z' || ch>='A'&&ch<='Z')
            now++;
        if(ch=='0'&&ch=='9')
            nono++;
    }
    printf("The number of total character:%d\n",noc);
    printf("The number of  tabs:%d\n",not);
    printf("The number of  lines:%d\n",non);
    printf("The number of  words:%d\n",now);
    printf("The number of  number:%d\n",nono);
    printf("The number of  spaces:%d\n",nos);

    fclose(fp);
    return 0;
}
#include <stdio.h>
int main()
{
    FILE *fp=fopen("sample.txt","r");
    int ch;
    int nos=0,non=0,noc=0,not=0;
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    while(1)
    {
        ch=fgetc(fp);
        if(EOF==ch)
            break;
        noc++;
        if(ch==' ')
            nos++;
        if(ch=='\n')
            non++;
        if(ch=='\t')
            not++;
    }
    fclose(fp);
    printf("The number of characters=%d\n",noc);
    printf("The number of spaces=%d\n",nos);
    printf("The number of tabs=%d\n",not);
    printf("The number of lines=%d\n",non);
    return 0;
}

//Fputc
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    FILE *ft=fopen("Edit.txt","w");
    char ch[100];

    if(ft==NULL)
    {
        printf("Error!");
        exit(2);
    }
    printf("Enter a few lines:\n");
    gets(ch);
    int len =strlen(ch);
    for(int i=0;i<len;i++)
    {
        if(EOF==ft)
            break;

        fputc(ch[i],ft);
    }
    fclose(ft);
    return 0;
}

//Fgetc
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    FILE *ft=fopen("Edit.txt","r");
    int ch;

    if(ft==NULL)
    {
        printf("Error!");
        exit(2);
    }
    while(1)
    {
        ch=fgetc(ft);
        if(EOF==ch)
            break;
        printf("%c",ch);
    }
    fclose(ft);
    return 0;
}

//Fgets
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit.txt","r");
    char str[11];
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    while(fgets(str,10,fp)!=NULL)
    {
        printf("%s",str);
    }
    fclose(fp);
}

//Fputs
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit.txt","a");
    char str[20];

    printf("Enter your string:");
    while(strlen(gets(str))>0)
    {
        fputs(str,fp);
        fputs("\n",fp);
    }
    printf("Done.");
    fclose(fp);
}

//Fprintf
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct AK
{
    char name[100];
    char aim[100];
    int age;
}ak;
void main()
{
    FILE *fp;
    struct AK ak={"AK","Entrepenure",15};

    fp=fopen("Edit.txt","a");
    fprintf(fp,"%s\t%s\t%d\n",ak.name,ak.aim,ak.age);
    printf("Done.\n\n");
    fclose(fp);

    fp=fopen("Edit.txt","r");
    while(fscanf(fp,"%s\t%s\t%d\n",ak.name,ak.aim,ak.age)!=EOF)
        printf("%s\n%s\n%d\n",ak.name,ak.aim,ak.age);
    fclose(fp);
}

//Fscanf
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct AK
{
    char name[100];
    char aim[100];
    int age;
}ak;
void main()
{
    FILE *fp;
    struct AK ak={"AK","Entrepenure",15};
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }

    fp=fopen("Edit.txt","r");
    while(1)
    {
        if(fp==NULL)
        {
            printf("Done.");
            break;
        }
        fscanf(fp,"%s\t%s\t%d\n",ak.name,ak.aim,ak.age);
        printf("%s\t%s\t%d\t",ak.name,ak.aim,ak.age);
    }
    fclose(fp);
}

//Fwrite
//Fread
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct AK
{
    char name[100];
    char aim[100];
    int age;
}ak;
void main()
{
    FILE *fp;
    fp=fopen("Edit2.txt","wb");
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    struct AK ak={"AK","Robotics",15};
    fwrite(&ak,sizeof(ak),1,fp);
    fclose(fp);

    fp=fopen("Edit2.txt","rb");
    if(fp==NULL)
    {
        printf("Error!");
        exit(4);
    }
    while(fread(&ak,sizeof(ak),1,fp)==1)
        printf("%s\t%s\t%d\t",ak.name,ak.aim,ak.age);
    fclose(fp);
}

//Modifying record
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp;
    long int pos;
    fp=fopen("Edit2.txt","w");
    if(fp==NULL)
    {
        printf("Error!");
        exit(1);
    }
    remove(fp);

    char str[100],str1[100];
    printf("Enter your sting:");
    while(strlen(gets(str))>0)
    {
        fputs(str,fp);
        fputs("\n",fp);
    }
    fclose(fp);
    fp=fopen("Edit2.txt","r+");
    printf("Enter the position (from end) where you want to apppend=");
    scanf("%d\n",&pos);
    while(fread(&str,pos,1,fp)==1)
    {
        printf("Enter the data:");
        gets(str1);
        fseek(fp,pos,SEEK_END);
        fputs(str1,fp);
        break;
    }
    fclose(fp);
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit2.txt","r+");
    fseek(fp,0,SEEK_CUR);
    fputs("[[AK]]",fp);
    printf("Done.");
    fclose (fp);
}
//Fseek
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
    FILE *fp=fopen("Edit2.txt","r+");
    fseek(fp,0,SEEK_END);
    printf("Current position:%ld\n",ftell(fp));
    fseek(fp,10,SEEK_SET);
    int ch;
    printf("After 10 bytes position:");
    while((ch=fgetc(fp))!=EOF)
        putchar(ch);

    fclose (fp);
}

//Low-Level File I/O
#include "sys\\types.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys\\stat.h>
void main()
{
    char buffer[500],inf[200],otf[200];
    int ch;
    int src=open("Edit.txt",O_RDONLY);
    if(src==-1)
    {
        printf("Error!(1)");
        exit(1);
    }
    int trg=open("Input.txt",O_CREAT | O_WRONLY);
    if(trg==-1)
    {
        printf("Error!(2)");
        close(src);
        exit(2);
    }
    while(1)
    {
        ch=read(src,buffer,500);
        if(ch>0)
            write(trg,buffer,ch);
        else
            break;
    }
    printf("Done.");
    close(src);
    close(trg);
}
