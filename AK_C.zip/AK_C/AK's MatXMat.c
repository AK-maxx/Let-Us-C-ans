#include <stdio.h>
#include <stdlib.h>
#include "array_1.h"
#include "array_2.h"
int main()
{
    int *arr;
    int *arr_2;
    int d,e;
    int r_2,c_2;
    int r,c;
    int sum=0;
    array_1(&arr,r,c);
    array_2(&arr_2,r_2,c_2);
    for(d=0;d<r;d++)
    {
        for(e=0;e<c_2;e++)
        {
            sum += arr[d][c_2] * *arr_2[c_2][r];
            printf("%d",sum);
        }
        printf("\n");
        sum=0;
    }
    return 0;
}
