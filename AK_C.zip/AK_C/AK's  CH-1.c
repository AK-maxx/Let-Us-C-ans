//Q-1
#include<stdio.h>
int main()
{
	float dd_al,bs_sal,rt_al,grs_sal;
	printf("enter the required entries");
	scanf("%f\n",&bs_sal);
	
	dd_al=40*bs_sal;
	rt_al=20*bs_sal;
	grs_sal=dd_al+bs_sal+rt_al;
	
	printf("%f\n",grs_sal);
	return 0;
}
//Q-2
#include <stdio.h>
int main()
{
   float dtab,cm,in,m,ft;
   
   printf("enter the distance between the two cities");
   scanf("%f\n",&dtab);
   
   m=dtab*1000;
   cm=dtab*100000;
   ft=dtab*3280.1;
   in=dtab*39370;
   
   printf("cm=%f\nm=%f\nft=%fin=%f"cm,m,ft,in);
   return 0;
}     
//Q-3
#include<stdio.h>
int main()
{
	float hin,maths,eng,sci,sst,tt_mper_m,avg_m;
	
	tt_m=hin+maths+sst+sci+eng;
	printf("enter marks of english,hindi,maths,science,social studies");
	scanf("%f%f%f%f",&eng,&hin,&maths,&sci,&sst);
	
    tt_m=hin+sst+sci+maths+eng;
	avg=tt_m/5;
	per_m=tt_m*100/500;
	printf("%f\n%f\n%f\n",tt_m,per_m,avg_m);
	return 0;
}
//Q-4
#include<stdio.h>
int main()
{
   float f,c;
   
   printf("enter fahrenheit");
   scanf("%f\n",&f);
   
   c=(f-32)*5/9;
   printf("%f\n",c);
   return 0;
   
} 
//Q-5
#include<stdio.h>
int main()
{
	float l,b,rdi,peri_rect,peri_cirl,area_rect,area_cirl;
	
	printf("enter lenght,breadth and radius");
	scanf("%f%f%f",&l,&b,&rdi);
	
	peri_rect=2*(l+b);
	peri_cirl=2*22/7*rdi;
	area_rect=l*b;
	area_cirl=22/7*rdi*rdi;
	
	printf("perimeter of rectangle=%f\nperimeter of circle=%f\narea of rectangle=%f\narea of circle=%f\n",peri_rect,peri_cirl,area_rect,area_cirl);
	return 0;
}  
