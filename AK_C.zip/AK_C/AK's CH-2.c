//Q-1
#include<stdio.h>
int main()
{
	 float a,b,c,d,e,tal;
	 printf("enter the five digit no.");
	 scanf("%f%f%f%f%f",&a,&b,&c,&d,&e);
	 
	 tal=a+b+c+d+e;
	 printf("%f\n",tal);
	 
	 return 0;
} 
//Q-2
#include<stdio.h>
int main()
{
    int no;
	printf("enter the number");
	scanf("%d",&no);
	if(no%2==0)                                         
	 printf("this is even%d",no);
	else
	 printf("this is odd%d",no);
	 return 0;
}                                                                                                                 