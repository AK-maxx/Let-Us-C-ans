/*
#include <stdio.h>
int main()
{
    int a=123;
    printf("The value of a=%20d\n",a);
    printf("The vlaue of a is %-2d\n",a);
    return 0;
}
*/
#include <stdio.h>
int main()
{
    int i=2113;
    char ch='A';
    float s=234.3;
    char str[100];
    printf("The value of i=%d\n",i);
    printf("The value of ch=%d\n",ch);
    printf("The value of s=%f\n",s);
    sprintf(str,"%d\t%d\t%f\n",i,ch,s);
    printf("\n\n");
    printf("Value of the string=%s\n",str);
    return 0;
}
