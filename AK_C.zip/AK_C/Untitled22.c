#include <stdio.h>
int main()
{
    int n,sum=0;
    for(n=1;n<=100;n++)
    {
        sum+=n;
    }
    printf("the sum is:%d\n",sum);
    return 0;
}
