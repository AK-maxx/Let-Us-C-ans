#include<stdio.h>
int main()
{
    int me;

    printf("enter 1 if you want to see my name");
    scanf("%d",&me);

    if(me==1)
  { printf(" &&&&&&&&&&&     &     &&   &&&&&&&&&&&       &&&&&&&&     &         & \n ");
    printf("&         &     &    &&    &         &       &            &         & \n ");
    printf("&         &     &   &&     &         &       &            &         & \n ");
    printf("&&&&&&&&&&&     &&&&&      &&&&&&&&&&&       &&&&&&&&     &&&&&&&&&&& \n ");
    printf("&         &     &&&        &         &              &     &         & \n ");
    printf("&         &     & &&       &         &              &     &         & \n ");
    printf("&         &     &   &&     &         &       &&&&&&&&     &         & \n ");
  }
   else
   printf("Go to hell");

   return 0;
}
