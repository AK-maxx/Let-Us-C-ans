rect(int *l,int *b)
{
    return ( *l * *b);
}
