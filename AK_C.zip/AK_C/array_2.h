int j,i;
void array_2(int **arr_2,int r_2,int c_2)
{
    printf("Enter the number of rows");
    scanf("%d\n",&r_2);
    printf("Enter the number of columns");
    scanf("%d\n",&c_2);

    arr_2=(int **)malloc(r_2*sizeof(int*));
    for(j=0;j<c_2;j++)
        {
            arr_2[j]=(int *)malloc(c_2*sizeof(int));
        }

    for(i=0;i<c_2;i++)
    {
        for(j=0;j<r_2;j++)
        {
            printf("\nelement:arr[%d][%d]====",i,j);
            scanf("%d\n",&arr_2[i][j]);
        }
    }
    for(i=0;i<c_2;i++)
    {
        for(j=0;j<r_2;j++)
        {
            printf("your values are:%d\n", arr_2[i][j]);
        }
    }
}
