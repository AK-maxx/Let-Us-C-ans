#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char *argv[])
{
    FILE *fp,*fs;
    int ch;
    if(argc!=3)
    {
        printf("Error!: No. of arguments incorrect\nExit code: (1)\n");
        exit(1);
    }
    fp=fopen(argv[1],"r");
    if(fp==NULL)
    {
        printf("Error!: file can't be opened\nExit code: (2)\n");
        exit(2);
    }
    fs=fopen(argv[2],"w");
    if(fs==NULL)
    {
        printf("Error!: file can't be opened\nExit code: (3)\n");
        fclose(fp);
        exit(3);
    }
    while((ch=fgetc(fp))!=EOF)
        fputc(ch,fs);
    fclose(fp);
    fclose(fs);
    return 0;
}
