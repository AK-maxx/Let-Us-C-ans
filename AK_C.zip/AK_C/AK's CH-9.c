//Q-1
#include <stdio.h>
void summ(int *,int *,int *,int *,int *,int *,int *);
void main()
{
    int n1,n2,n3,n4,n5,sum,avg;

    printf("Enter 1st number=");
    scanf("%d\n",&n1);
    printf("Enter 2nd number=");
    scanf("%d\n",&n2);
    printf("Enter 3rd number=");
    scanf("%d\n",&n3);
    printf("Enter 4th number=");
    scanf("%d\n",&n4);
    printf("Enter 5th number=");
    scanf("%d\n",&n5);

    summ(&n1,&n2,&n3,&n4,&n5,&sum,&avg);
    summ(&n1,&n2,&n3,&n4,&n5,&sum,&avg);

    printf("Their sum is=%d\n",sum);
    printf("Their average is=%d\n",avg);
}
void summ(int *n1,int *n2,int *n3,int *n4,int *n5,int *sum,int *avg)
{
    *sum= *n1+ *n2+ *n3+ *n4+ *n5;
    *avg= *sum/5;
}
//Q-2
#include <stdio.h>
void cal(int *,int *,int *,float *,float *);
void main()
{
    int m1,m2,m3;
    float avg,per;

    printf("Enter your marks in 1st subject=");
    scanf("%d\n",&m1);
    printf("Enter your marks in 2nd subject=");
    scanf("%d\n",&m2);
    printf("Enter your marks in 3rd subject=");
    scanf("%d\n",&m3);

    cal(&m1,&m2,&m3,&avg,&per);
    cal(&m1,&m2,&m3,&avg,&per);

    printf("Average=%f\n",avg);
    printf("Percent=%f\n",per);
}
void cal(int *m1,int *m2,int *m3,float *avg,float *per)
{
    *avg= (*m1+ *m2+ *m3)/3;
    *per= (*m1+ *m2+ *m3)*100 /240;
}
//Q-5
#include <stdio.h>
void areaa(int *,int *,int *,float *);
void main()
{
    int s1,s2,s3;
    float area;

    printf("Enter the 1st value=");
    scanf("%d\n",&s1);
    printf("Enter the 2nd value=");
    scanf("%d\n",&s2);
    printf("Enter the 3rd value=");
    scanf("%d\n",&s3);

    areaa(&s1,&s2,&s3,&area);

    printf("Area is=%f\n",area);
}
void areaa(int *s1,int *s2,int *s3,float *area)
{
    *area= (*s1+ *s2+ *s3)/2;
}

