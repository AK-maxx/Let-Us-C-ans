//Sample Q
#include<stdio.h>
int my(int aa,int bb);
int main()
{
    int wrd,wrd_2,sum,sub;
    prtfEnter the number");
    scanf("%d%d",&wrd,&wrd_2);
    sum=my(wrd);
    sub=my(wrd_2);
    printf("Here is sum=%d and here is sub=%d",sum,sub);
    return 0;
}
int my(int aa,int bb)
{
    int sum,sub;
    sum=aa+bb;
    sub=aa-bb;
    return (sum,sub);
}
//sample Q-2
#include <stdio.h>
int sub_a(int,int);
int sum_a(int,int);
int main()
{
	int a,b,sum,sub;
	printf("Enter the values of a and b");
	scanf ("%d%d\n",&a,&b);
	sum=sum_a(a,b);
	sub=sub_a(a,b);
	printf("The s
	return 0;
}
int sum_a(int a,int b)
{
	int e;
	e=a+b;
	return (e);
}
int sub_a(int a,int b)
{
	int f;
	f=a-b;
	return (f);
}
//Sample Q-3
#include <stdio.h>
int main()
{
	int a=5,*b,*c;
    b=&a;
    c=&b;
    printf("Value of a=%d\n",a);
	printf("Address of a=%u\n",&a);
	printf("Value of b=%d\n",b);
	printf("Address of b=%u\n",&b);
	printf("value of c=%d\n",c);
	printf("Address of c=%u\n",&c);
	printf("\n");
	printf("value of b=%d\n",*b);
	printf("value of c=%d\n",*c);
	return 0;
}
