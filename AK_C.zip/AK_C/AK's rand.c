#include <stdio.h>
#include <stdlib.h>
void main()
{
    for(int i=0;i<10;i++)
    {
        printf("%d ",rand());
    }
}
