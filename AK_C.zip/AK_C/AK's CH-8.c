//Ex-B
//Q-1
#include<stdio.h>
int addmult(int,int)
int main()
{
	int i=3,j=4,k,l;
	k=addmult(i,j);
	l=addmult(i,j);
	printf("%d%d\n",k,l);
	return 0;
}
int addmult(int ii,int jj)
{
	int kk,ll;
	kk=ii+jj;
	ll=ii*jj;
	return(kk,ll);
}
//Q-2
#include<stdio.h>
void message();
int main()
{
	int a=message();
	return 0;
}
void message()
{
	int m;
	pritnf("Viruses are written in C\n",m);
	return (m);
}
//Q-3
#include <stdio.h>
int main()
{
	float a=15.5;
	char ch='C';
	printit(a,ch);
	return 0;
}
printit()
{
	printf("%f%c\n",a,ch);
}
//Q-4
#include <stdio.h>
void message();
int main()
{
	message();
	message();
	return 0;
}
void message'()
{
	printf("Praise worthy and C worthy both are synonyms\n");
}
//Q-5
#include <stdio.h>
int main()
{
	let_us_C()
	{
		printf("C is a simple minded language!\n");
		printf("others are of of course no match!\n");
	}
	return 0;
}
//Q-6
#include <stdio.h>
void message();
int main()
{
	message(message());
	return 0;
}
void message()
{
	printf("It's a small world after all..\n");
}
