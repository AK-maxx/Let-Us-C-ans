#include <stdio.h>
int cal(int ar[],int num)
{
    int i,sum=0;
    for(i=0;i<num;i++)
    {
        sum += ar[i];
    }
    return sum;
}
int main()
{
    int arr[5]={1,2,3,4,5};
    int sum;
    sum=cal(arr,5);
    printf("Sum of array elements=%d\n",sum);
    return 0;
}
