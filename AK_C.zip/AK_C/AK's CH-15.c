//P to demonstrate printing of strings
/* #include <stdio.h>
int main()
{
    char ch[5]="Akash";
    int i;
    printf("The characters are:");
    for(i=0;i<5;i++)
    {
        printf("%c",ch[i]);
    }
    return 0;
}
//P to demonstrate printing of strings using pointers
#include <stdio.h>
int main()
{
    char ch[]="Akash";
    char *ptr;
    ptr=ch;
    printf("The characters are:");
    while( *ptr!='\0')
    {
        printf("%c", *ptr);
        ptr++;
    }
    return 0;
}
//Entering the string form keyboard
#include <stdio.h>
int main()
{
    char name[10];
    printf("Enter your name:");
    scanf("%s",name);
    printf("Hello %s!",name);
    return 0;
}
//Entering the string form keyboard using gets and puts
#include <stdio.h>
int main()
{
    char name[100];
    printf("Enter your name");
    gets(name);
    puts("hello!");
    puts(name);
    return 0;
}
//Entering the string form keyboard using scanf
#include <stdio.h>
int main()
{
    char name[100];
    printf("Enter your name:");
    scanf("%[^\n]s",name);
    printf("Hello %s!",name);
    return 0;
}
//Pointers and strings
//1
#include <stdio.h>
int main()
{
    char name_f[100];
    char name_l[100];
    char *ptr1, *ptr2;
    ptr1=name_f;
    ptr2=name_l;

    printf("Enter your first name:");
    scanf("%[^\n]s",name_f);
    printf("Enter your last name:");
    gets(name_l);

    name_f=name_l;  //error
    ptr1=ptr2;      //correct
    printf("%d", *ptr1);
    printf("%s",name_f);

    return 0;
}
//2
#include <stdio.h>
int main()
{
    char name_f[10]="Akash";
    char name_l[10]="Kumar";
    char *ptr1, *ptr2;
    ptr1=name_f;
    ptr2=name_l;

    name_f=AK;  //error
    ptr1=name_l;      //correct
    printf("%d", *ptr1);
    printf("%s",name_f);

}
//String.h library
//Using Strlen()
#include <stdio.h>
#include <string.h>
int main()
{
    char name_f[10]="Akash";
    int len;
    len=strlen(name_f);
    printf("string:%s\nlenght:%d",name_f,len);

    return 0;
}
//Without using Strlen
#include <stdio.h>
#include <string.h>
int xstrlen(char *);
int main()
{
    char name[]="Akash Kumar i.e. AK will become a trilionaire one day";
    int len;

    len=xstrlen(name);
    printf("string:%s\nlenght:%d",name,len);

    return 0;
}
int xstrlen(char *n)
{
    int len=0;
    while( *n!='\0')
    {
        len++;
        n++;
    }
    return len;
}
//strcyp
#include <stdio.h>
#include <string.h>
int main()
{
    char name_1[100];
    char name_2[100];

    printf("Enter the name in first string:");
    gets(name_1);

    strcpy(name_2,name_1);

    printf("Name in first string:%s\n",name_1);
    printf("Name in second string:%s\n",name_2);

    return 0;
}
//xstrcpy
#include <stdio.h>
void xstrcpy(char *,char *);
int main()
{
    char name_1[100];
    char name_2[100];

    printf("Enter the name in first string:");
    gets(name_1);

    xstrcpy(name_2,name_1);

    printf("Name in first string:%s\n",name_1);
    printf("Name in second string:%s\n",name_2);

    return 0;
}
void xstrcpy(char *n2,char *n1)
{
    while( *n1!='\0')
    {
        *n2= *n1;
        n2++;
        n1++;
    }
    *n2='\0';
}
//strcat
#include <stdio.h>
#include <string.h>
int main()
{
    char name_1[100];
    char name_2[100];

    printf("Enter the name in first string:");
    gets(name_1);
    printf("Enter the name in second string:");
    gets(name_2);

    strcat(name_2,name_1);
    printf("Name in first string:%s\n",name_1);
    printf("Name in second string:%s\n",name_2);

    return 0;
}
//strcmp
#include <stdio.h>
#include <string.h>
int main()
{
    char ch1[]="abcde";
    char ch2[]="abdde";
    char ch3[]="bcdea";

    int i,k,l;

    k=strcmp(ch1,ch2);
    i=strcmp(ch1,"abcde");
    l=strcmp(ch3,ch1);

    printf("%d\n%d\n%d\n",k,i,l);
    return 0;
}
//Exercise
//A
//1
#include <stdio.h>
int main()
{
    char ch[2]="A";
    printf("%c\n",ch[0]);
    printf("%s\n",ch);
    return 0;
}
//2
#include <stdio.h>
int main()
{
    char ch[]="AK is Great!!!";
    printf("%c\n",ch[2]);
    printf("%s\n",ch);
    printf("%s\n",&ch);
    printf("%s\n",&ch[5]);

    return 0;
}
//3
#include <stdio.h>
int main()
{
    char ch[]="AK is Great!!!";
    int i=0;
    while(ch[i]!='\0')
    {
        printf("%c%c\n",ch[i], *(ch+i));
        printf("%c%c\n",i[ch], *(i+ch));
        i++;
    }
    return 0;
}
//4
#include <stdio.h>
int main()
{
    char ch[]="AK is Great!!!";
    char ch2[100];
    char *tt=ch2, *ss=ch;
    int i=0;
    while(ch[i]!='\0')
    {
        *tt++ = *ss++;
        i++;
    }
    printf("%s\n",ch2);
    return 0;
}
//5
#include <stdio.h>
void main()
{
    char ch1[]="AK is Great!!!";
    char ch2[]={'A','K','_','i','s','_','G','r','e','a','t','!','!','!'};

    printf("%s\n",ch1);
    printf("%s\n",ch2);
}
//6
#include <stdio.h>
void main()
{
    printf(5+"AK is Great");
    printf("\n");
    printf("%c\n","Akash Kumar is AK"[10]);
}
//7
#include <stdio.h>
void main()
{
    printf("%c\n%c\n%c\n",sizeof('3'),sizeof("3"),sizeof(3));
} */
