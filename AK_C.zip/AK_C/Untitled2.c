//Sample Q
#include<stdio.h>
int my(int aa,int bb);
int main()
{
    int wrd,wrd_2,sum,sub;
    printf("fEnter the number");
    scanf("%d%d",&wrd,&wrd_2);
    sum=my(wrd);
    sub=my(wrd_2);
    printf("Here is sum=%d and here is sub=%d",sum,sub);
    return 0;
}
int my(int aa,int bb)
{
    int sum,sub;
    sum=aa+bb;
    sub=aa-bb;
    return (sum,sub);
}
//sample Q-2
#include <stdio.h>
int sub_a(int,int);
int sum_a(int,int);
int main()
{
	int a,b,sum,sub;
	printf("Enter the values of a and b");
	scanf ("%d%d\n",&a,&b);
	sum=sum_a(a,b);
	sub=sub_a(a,b);
	printf("The sum is=%d\nThe is sub= %d\n",sum,sub);
	return 0;
}
int sum_a(int a,int b)
{
	int e;
	e=a+b;
	return (e);
}
int sub_a(int a,int b)
{
	int f;
	f=a-b;
	return (f);
}
