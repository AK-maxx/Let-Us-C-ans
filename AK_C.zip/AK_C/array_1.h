int j,i;
void array_1(int **arr,int r,int c)
{
    printf("Enter the number of rows");
    scanf("%d\n",&r);
    printf("Enter the number of columns");
    scanf("%d\n",&c);

    arr=(int **)malloc(r*sizeof(int*));
    for(j=0;j<c;j++)
        {
            arr[j]=(int *)malloc(c*sizeof(int));
        }

    for(i=0;i<c;i++)
    {
        for(j=0;j<r;j++)
        {
            printf("\nelement:arr[%d][%d]====",i,j);
            scanf("%d\n",&arr[i][j]);
        }
    }
    for(i=0;i<c;i++)
    {
        for(j=0;j<r;j++)
        {
            printf("your values are:%d\n", arr[i][j]);
        }
    }
}
