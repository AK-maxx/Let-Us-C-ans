//Q-36
#include <stdio.h>

void main()
{

    int pass,w;
    for(w=1;w<=10;w++)
    {
        printf("Enter the password\n");
        scanf("%d",&pass);

        if(pass==1039)
        {
            printf("This is the correct password\n");
            break;
        }
        else
        printf("This is an incorrect password\n");
    }
}
/*
//Q-9
#include <stdio.h>
void main()
{
	float itw1,itw2,itn1,itn2,a,avg;

	for(a=1;a<=2;a++)
	{
		printf("Enter the weight of first item=\n");
		scanf("%f",&itw1);

		printf("Enter the weight of second item=\n");
		scanf("%f",&itw2);

		printf("Enter the number of first item=\n");
		scanf("%f",&itn1);

		printf("Enter the number of second item=\n");
		scanf("%f",&itn2);

		avg=(itw1+itw2+itn1+itn2)/4;
		printf("The expected outcome is=%f\n",avg);
	}
}

//Q-12
#include<stdio.h>
void main()
{
	int epid,x;
	float sal,tsal,x,hrsw;
	for(x=1,x<=10,x++)
	{
		printf("Enter your ID=\n");
		scanf("%d",&epid);

		printf("Enter the hours worked by you=\n");
		scanf("%f",&hrsw);

		printf("Enter the amount you will get by working per hour=\n");
		scanf("%f",&sal);

		tsal=sal*hrsw;


		printf("Employee ID=%d\nYour total salary is=%f\n",epid,tsal);

	}
}
//Q-6
#include<stdio.h>
void main()
{
	int abcd,num;

	printf("Enter the number to be expresed in the form of table=\n");
	scanf("%d",&num);

	for(abcd=2;abcd<=1000;abcd++)
	{
		printf("%dX%d=%d\n",num,abcd,num*abcd);
	}
}
*/
