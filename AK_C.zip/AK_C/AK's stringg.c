/* #include <stdio.h>
struct ak
{
    char name[100];
    int age;
    char icon[10];
}a;
int main()
{
    printf("Enter your personal details of AK:\n");
    printf("Enter your name:");
    gets(a.name);
    printf("Enter your icon:");
    gets(a.icon);
    printf("Enter your age:");
    scanf("%d\n",&a.age);

    printf("AK's personal details:\n");
    printf("Name:%s\n",a.name);
    printf("Age:%d\n",a.age);
    printf("Authentic name:%s\n",a.icon);

    return 0;
}

#include <stdio.h>
struct ak
{
    char name[100];
    int age;
    char icon[10];
};
int main()
{
    struct ak *ptr;
    printf("Enter your personal details of AK:\n");
    printf("Enter your name:");
    gets(ptr->name);
    printf("Enter your icon:");
    gets(ptr->icon);
    printf("Enter your age:");
    scanf("%d\n", &(ptr)->age);

    printf("AK's personal details:\n");
    printf("Name:%s\n",ptr->name);
    printf("Age:%d\n",ptr->age);
    printf("Authentic name:%s\n",ptr->icon);

    return 0;
} */
//Q-1
