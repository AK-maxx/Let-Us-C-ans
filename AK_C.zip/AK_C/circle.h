circle(float r)
{
    float pi=3.147;
    return (pi * r * r);
}
