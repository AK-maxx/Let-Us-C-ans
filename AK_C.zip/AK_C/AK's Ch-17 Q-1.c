#include <stdio.h>
// #include "name.h"
// #include "roll.h"
struct student
{
    char name[10] ;
    int rollno ;
    char course[10] ;
    int year ;
};
int main()
{
    struct student stud[2];
    int r,i;

    for(i=0;i<2;i++)
    {
        printf("Student %d:\n",i+1);

        printf("Enter your name:");
        scanf("%s\n",&stud[i].name);
        printf("\n");
        printf("Enter your course:");
        scanf("%s\n",&stud[i].course);
        printf("\n");
        printf("Enter your roll number:");
        scanf("%s\n",&stud[i].rollno);
        printf("Enter your year of admission:");
        scanf("%s\n",&stud[i].year);
    }

    printf("enter the roll number:");
    scanf("%d\n",&r);

    for(i=0;i<2;i++)
    {
        if(stud[i].rollno==r)
        {
            printf("Name:%s\n",stud[i].name);
            printf("Roll number:%d\n",stud[i].rollno);
            printf("Course:%s\n",stud[i].course);
            printf("Year:%d\n",stud[i].year);
        }
    else
        printf("Wrong roll number!\n");
    }
    return 0;
}

