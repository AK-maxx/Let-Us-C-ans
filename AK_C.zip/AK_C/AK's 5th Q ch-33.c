//i can't do 4th Q.
//5th Q of ch-3    check whether the no. is palindrome or not
#include<stdio.h>
int main()
{
   int a,b,c,d,e,f,g,h,i,j;
   
   printf("enter the number");
   scanf("%d",&a);
   
   b=a%10;
   c=a/10;
   d=c%10;
   e=c/10;
   f=e%10;
   g=e/10;
   h=g%10;
   i=g/10;
   j=10000*b+1000*d+100*f+10*h+i;
   
   printf("The reversed no.is %d",j);
   
   if(a==j)
      printf("\nThe reversed Number and Original number are Equal");
   else
      printf("\nThe reversed Number and original Number are not Equal");
	  
   return 0;
}