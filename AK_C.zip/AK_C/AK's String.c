//Q-2
/* #include <stdio.h>
int main()
{
    char ch[100];
    int len=1,i;
    printf("Enter the string:");
    gets(ch);
    for(i=0; ch[i] != '\0';i++)
    {
        len++;
    }
    printf("string:%s\nLenght:%d\n",ch,len-1);
    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
    char ch[100];
    int i;
    printf("Enter the string:");
    gets(ch);
    for(i=0; ch[i] !='\0';i++)
    {
        printf("%c ",ch[i]);
    }
    printf("\n");
    return 0;
}
//Q-5
#include <stdio.h>
int main()
{
    char ch[100];
    int i,len=1,len2=1;
    printf("Enter the string:");
    gets(ch);
    for(i=0; ch[i] !='\0';i++)
    {
        if(ch[i]==' ' || ch[i]=='\n' ||ch[i]=='\t')
        {
            len++;
        }
        else
            len2++;
    }
    printf("String:%s\nNumber of words=%d\n",ch,len);
    return 0;
}
//Q-7
#include <stdio.h>
#include <string.h>
int main()
{
    char str[100];
    int i;
    int wd,dt,spl;
    wd= dt= spl=0;

    printf("Enter the sentence:");
    gets(str);

    for(i=0; str[i] != '\0';i++)
    {
        if(str[i]<='Z' && str[i]>='A' || str[i]<='z' && str[i]>='a')
        {
            wd++;
        }
        else if(str[i]<='9' && str[i]>='0')
        {
            dt++;
        }
        else
            spl++;
    }
    printf("String:%s\n", str);
    printf("Lenght of alphabets=%d\n", wd);
    printf("Lenght of digits=%d\n", dt);
    printf("Lenght of special symbols=%d\n", spl);

    return 0;
}
//Q-11
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    char str[100];
    int i,temp;
    int j,len;

    printf("Enter the sentence:");
    gets(str);
    len=strlen(str);

    for(j=1; j<=len;j++)
    {
        for(i=0; i<len;i++)
        {
            if(str[i]>str[i+1])
            {
                temp=str[i];
                str[i]=str[i+1];
                str[i+1]=temp;
            }
        }
    }
    printf("String after sorting%s\n",str);

    return 0;
}
//Q-18
#include <stdio.h>
int main()
{
    char str[1000],cho;
    int i,n=1;

    printf("Enter the string:");
    gets(str);
    printf("Enter the character you want to search=");
    scanf("%c\n",&cho);

    for(i=0; str[i]!='\0';i++)
    {
        if(str[i]==cho)
            n++;
    }
    printf("The character %c occurence=%d\n",cho,n-1);
    return 0;
} */
//Q-1
#include <stdio.h>
#include <string.h>
int main()
{
    char str[100];

    printf("Enter the string:");
    gets(str);
    len=strlen(str);
    t=(str)
    for(i=0;i<len;i++)
    {

    }
}
