//Rough practice for array
//1
/* #include <stdio.h>
int main()
{
    int std[4][2];
    int a,i;

    for (a=0;a<=3;a++)
    {
        printf("enter roll no.and marks");
        scanf("%d%d\n",&std[a][0],&std[a][1]);
    }
    for(i=0;i<=3;a++)
        printf("Roll no.=%d\tMarks=%d\n",std[i][0],std[i][1]);

    return 0;
}
//2
#include <stdio.h>
int main()
{
    int arr[4][2]={
        {123,12},
        {234,24},
        {345,36},
        {456,48}
                  };
    int a,i;
    for(a=0;a<=3;a++)
    {
        for(i=0;i<=1;i++)

            printf("%d\t", *(*(arr+a)+i));
            printf("%d\t", *(arr[a]+i));
            printf("%d\t", arr[a][i]);

            printf("\n");
    }
    return 0;
}
//3
#include <stdio.h>
int main()
{
    int arr[4][2]={
        {123,12},
        {234,24},
        {345,36},
        {456,48}
                  };
    int a,i,(*p)[2];
    int *pint;

    for(a=0;a<=3;a++)
    {
        p=&arr[a];
        pint=(int *)p;
        printf("\n");

        for(i=0;i<=1;i++)
            printf("%d\t", *(pint+i));
    }
    return 0;
}
//4
#include <stdio.h>
#define A 4
#define S 2
void display(int [][2]);
int main()
{
    int arr[A][S]={
        {123,12},
        {234,24},
        {345,36},
        {456,48}
                  };
    display(arr);
    return 0;
}
void display(int arr[][2])
{
    int a,i;

    for(a=0;a<=3;a++)
    {
        for(i=0;i<=1;i++)
            printf("%d\t",arr[a][i]);
        printf("\n");
    }
    printf("\n");
}
//5
#include <stdio.h>
int main()
{

    int *arr[5];
    int i,j,k,l,a;

    printf("enter the value of the i numbers");
    scanf("%d",&i);
    printf("enter the value of the j numbers");
    scanf("%d",&j);
    printf("enter the value of the k numbers");
    scanf("%d",&k);
    printf("enter the value of the l numbers");
    scanf("%d",&l);

    arr[0]=&i;
    arr[1]=&j;
    arr[2]=&k;
    arr[3]=&l;

    printf("The numbers are:\n");
    for(a=0;a<=3;a++)
    {
        printf("%d\n",*(arr[a]));
    }
    return 0;
}
//6
#include <stdio.h>
int main()
{
    static int a[]={1,2,3,4,5};
    int *p[]={a,a+1,a+2,a+3,a+4};
    printf("%u\t%u\t%d\n",p, *p, *(*p));
    return 0;
}
//A
//Q-1
#include <stdio.h>
int main()
{
    int n[3][3]={
        1,2,3,
        4,5,6,
        7,8,9
                };
    printf("%d\n%d\n%d\n", *n,n[1][1],n[2][2]);
    return 0;
}
//Q-2
#include <stdio.h>
int main ()
{
    int n[3][3]={
        1,2,3,
        4,4,4,
        7,8,9
                };
    int i,*prt;
    prt=&n[0][0];
    for(i=0;i<9;i++)
    {
        printf("number=%d\n" ,*(prt+i));
    }
    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
    int n[3][3]={
        1,2,3,
        4,4,4,
        7,8,9
                };
    int i,a;
    for(i=0;i<3;i++)
    {
        for(a=0;a<3;a++)
            printf("Number=%d\t%d\n",n[i][a], *(*(n+i)+a));
    }
    return 0;
}
//B
//Q-1
#include <stdio.h>
int main()
{
    int n[][3]={
        1,2,3,
        4,4,4,
        7,8,9
                };
    printf("%d\n",n);
    return 0;
}
//Q-2
#include <stdio.h>
int main()
{
    int n[][3]={
        1,2,3,
        4,4,4,
        7,8,9
                };
    printf("%d\n",n[1][1]);
    return 0;
}
//C
//Q-1
#include <stdio.h>
int main()
{
    int theed[4][2][3]={
                         { {1,2,3},
                           {1,2,4}
                         },

                         { {2,2,3},
                           {2,2,4}
                         },

                         { {3,2,3},
                           {3,2,4}
                         },

                         { {4,2,3},
                           {4,2,4}
                         },
                       };
    printf("First=%d\nLast=%d\n",theed[0][0][0],theed[3][1][2]);
    return 0;
}
//Q-2
#include <stdio.h>
#define R 3
#define C 3
int main()
{
    int arr[R][C]={
                    {1,2222,3},
                    {4,5,6},
                    {7,8,9}
                  };
    int *max,i,a;
    max=arr[0][0];

    for(i=0;i<=3;i++)
    {
        for(a=0;a<=3;a++)
        {
            if( *max < arr[a][i])
                max=arr[a][i];
        }
    }
   // printf("The minimum number is=%d\n",min);
    printf("The maximum number is=%d\n", *max);
    return 0;
}
//Q-5
#include <stdio.h>
int main()
{
    int arr[3][5]={
                    {1,2,3,4,5},
                    {6,7,8,9,10},
                    {11,12,13,14,15}
                  };
    int *n=&arr;

    printf("1.%d\n", *(*(arr+2)+1));
    printf("2.%d\n", *(*arr+2)+4);
    printf("3.%d\n", *(*(arr+1)));
    printf("4.%d\n", *(*(arr)+2)+1);
    printf("5.%d\n", *(*(arr+1)+3));
    printf("6.%d\n", *n);
    printf("7.%d\n", *(n+2));
    printf("8.%d\n", (*(n+3)+1));
    printf("9.%d\n", *(n+5)+1);
    printf("10.%d\n", ++*n);

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int **arr;
 //   int arr;
    int r,c,i,j,a=1;

   // printf("enter the size of matrix column X row");
  //  scanf("%d%d\n",&c,&r);

    printf("Enter the number of rows\n");
    scanf("%d\n",&r);
    printf("Enter the number of columns\n");
    scanf("%d\n",&c);

    arr=(int **)malloc(r*sizeof(int*));
    for(j=1;j<=c;j++)
        {
            arr[j]=(int *)malloc(r*sizeof(int));
        }

    for(i=0;i<=c;i++)
    {
        for(j=0;j<=r;j++)
        {
            printf("element:arr[%d][%d]\t",j,i);
            scanf("%d\n",&arr[j][i]);
            a++;
        }
    }
    for(i=0;i<=c;i++)
    {
        for(j=0;j<=r;j++)
        {
            printf("your values are:%d\n", arr[j][i]);
        }
    }
    return 0;
}
//sum of each row and column
#include <stdio.h>
int main()
{
    int arr[][3]={
                1,1,1,
                4,4,4,
                7,7,7
               };
    int i,a,sum=0;

    printf("The sum of each row:\t");
    for(i=0;i<=2;i++)
    {
        for(a=0;a<=2;a++)
        {
            sum+=arr[i][a];
        }
        printf("%d\t",sum);
        sum=0;
    }
    printf("\n");
    printf("The sum of each column:\t");
    for(i=0;i<=2;i++)
    {
        for(a=0;a<=2;a++)
        {
            sum+=arr[a][i];
        }
        printf("%d\t",sum);
        sum=0;
    }
    return 0;
} */
//Q-9
