/* //Rough practice
//1
#include <stdio.h>
#define AS 5
int main()
{
    int avg,sum=0,i;
    int marks[AS];
    for(i=0;i<=4;i++)
    {
        printf("enter the marks=\n");
        scanf("%d0",&marks[i]);
    }
    for(i=0;i<=4;i++)
        sum=sum+marks[i];
        avg=sum/5;

        printf("the average of you marks is=%d\n",avg);
    return 0;
}
//2
#include <stdio.h>
#define SIZE 5
int main()
{
    int  num[SIZE]={10,20,30,40,50};

    printf("The number in 1st position=%d\n",num[0]);
    printf("The number in 2nd position=%d\n",num[1]);
    printf("The number in 3rd position=%d\n",num[2]);
    printf("The number in 4th position=%d\n",num[3]);
    printf("The number in 5th position=%d\n",num[4]);

    return 0;

}
//3
//With pointers
#include <stdio.h>
void dis1(int);
void dis2(int*);
int main
{
    int i;
    int num[]={1,2,3,4,5};
    for (i=0;i<=4;i++)
        dis1(num[i]);

    for (i=0;i<=4;i++)
        dis2(&num[i]);

    return 0;
}

void dis1(int n1)
{
    printf("dis1=%d",n1);
}
void dis2(int *n2)
{
    printf("dis2=%d", *n2);
}
//4
#include <stdio.h>
int main()
{
    int i,*j;
    int n[]={1,2,3,4,5};

    j=&n[0];
    for (i=0;i<=4;i++)
    {
        printf("address=%u value=%d\n",j,*j);
        j++;
    }
    return 0;
}
//5
#include <stdio.h>
void dis1(int*,int);
void dis2(int [],int);
int main()
{
    int n[]={1,2,3,4,5,6};
    dis1(&n[0],6);
    dis2(&n[0],6);
    return 0;
}
void dis1(int *a,int n)
{
    int i;
    for(i=0;i<=n-1;i++)
    {
        printf("Dis1 value=%d\n",*a);
        a++;
    }
    printf("\n");
}
void dis2(int a[],int n)
{
    int i;
    for(i=0;i<=n-1;i++)
        printf("Dis2 value=%d\n",a[i]);
}

//6
//Flexible array
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int max,i,*p;
    printf("Enter the array size\n");
    scanf("%d",&max);

    p=(int *)malloc(max*sizeof(int));
    for(i=0;i<=max;i++)
    {
        p[i]=i*i;
        printf("%d\n",p[i]);
    }
    return 0;
}
//B
//Q-1 and Q-4
#include <stdio.h>
#define S 8
int main()
{
    int i,arr[S]={-66,-65,-3,-27,-5,-873,-56,-43};

    for(i=0;i<=7;i++)
    {
        printf("Number=%d",arr[i]);

        if(arr[i]%2==0)
            printf(" --even");
        if(arr[i]%2!=0)
            printf(" --odd");
        if(arr[i]<0)
            printf(" --Negative\n");
        if(arr[i]>0)
            printf(" --positive\n");
    }
    return 0;
}
//Q-2
#include <stdio.h>
#define AS 5
int main()
{
    int i,arr[AS]={1,2,3,4,5},ar[AS];
    for(i=4;i>=0;i--)
    {
        printf("%d\n",arr[i]);
    }
    return 0;
}
//Q-3
#include <stdio.h>
#define S 5
int main()
{
    int i,a,n,num=0,arr[S];

    printf("Enter the 5 number\n");
    for(i=0;i<=4;i++)
    {
        scanf("%d\n",&arr[i]);
    }

    printf("enter the number you want to see");
    scanf("%d\n",&n);

    for(a=0;a<=4;a++)
    {
        if(n==arr[a])
            num=1;
            printf("Gotcha%d\n",n);
        break;
    }
   // if(num==1)
   //     printf("The number is found");
   // else
  //      printf("can't find the number");

    return 0;
} */
//Q-7
#include <stdio.h>
void modify(int [],int);
int main()
{
    int arr[10]={1,2,3,4,5,6,7,8,9,10};

    printf("The multiplied number are:\n");
    modify(arr,10);

    return 0;
}
void modify(int arr[],int n)
{
    int a,b=3;
    printf("The multiplied number are:\n");
    for(a=0;a<n;a++)
    {
        printf("element=%d\tmultiplied=%d\n",arr[a],b*arr[a]);
    }
}
