//Q-1
#include <stdio.h>
int main()
{
    int sp,cp,gain,loss;
    printf("enter the cost price and the selling price\n");
    scanf("%d%d",&cp,&sp);
    if(sp>cp)
        gain=sp-cp;
    else 
       loss=cp-sp;
    printf("%d%d\n",gain,loss);
    return 0;
}
//Q-2
#include <stdio.h>
int main ()
{
    int inte;
    printf("enter no.");
    scanf("%d",&inte);
    
    if(inte%2==0)
     printf("this is even");
    
    else
     printf("this is odd");

    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
   int year;
   printf("enter the year");
   scanf("%d",&year);
   
   if(year%4==0)
      printf("This is not a leap year");
   else
      printf("This a leap year");
   return 0;
}
//Q-5
#include <stdio.h>
int main()
{
   int ram,shayam;
   printf("enter the year");
   scanf("%d",&year);
   
   if(year%4==0)
      printf("This is a leap year");
   else
      printf("This is not a leap year");
   return 0;
}
//Q-6
#include <stdio.h>
int main ()
{
    int ram,shyam,ajay;
    printf("enter the age of Ram ,Shyam );
    scanf("%d%d%d",&ram,&shyam,&ajay);
    
    if(ram>shyam&&shyam<ajay)
     printf("Shyam is youngest");
    
    else if(ram<shyam&&ram<ajay)
     printf("Ram is the youngest");
 
    else if(ajay<shyam&&ajay<ram)
     prinf("Äjay is the youngest") 
 
 return 0;
}//Q-7
#include <stdio.h> 
int main() 

{ 
   int asp,1ang,2ang,3ang;
    
   printf("enter 1st angle="); 
   scanf("%d",&1ang");
   
    printf("Enter 2st angle=\n");
    scanf(%d,&2ang);
	
	printf("Enter 3st angle=\n");
    scanf(%d,&3ang); 
	
	asp=1ang+2ang+3ang;
	if(asp==180)
	  printf("It can contribute to a triangle");
	  
	else
	  printf("It can't contribute to a triangle");
	  
	return 0;
} 
//Q-9
#include <stdio.h>
int main()
{
    int area,peri,len,bre;
	printf("enter the lenght=");
	scanf("%d",&len);
	
	printf("enter the breadth=");
	scanf("%d",&bre); 
	
	peri=2*(len+bre);
	area=len*bre;
	
	if(area>peri)
	  printf("area is larger");
	  
	else
	  printf("perimeter is larger");
	  
	return 0
}