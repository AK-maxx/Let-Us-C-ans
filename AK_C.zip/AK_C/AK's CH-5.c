//Q-1
#include <stdio.h>
int main()
{
    float empl;//,p_pay=12,paym/*,abcd*/,upay;

	//while(abcd+=10)
	{
	printf("Enter the hrs worked");
	scanf("%f\n",&empl);
    printf("%f\n",empl/2);
	if(empl>40)

	  upay=(empl-40)*12;
	   printf("%f\n",upay);

	else
	   printf("you will not get any extra payment");
	}
	return 0;
}
//Q-2
#include<stdio.h>
void main()
{ 
    int no;
	
	while(no==5)
	{
		printf("Enter the first numbers of your choice");
	    scanf("%d",&no);
	
		if(no/no==1)
		printf("This is a positive number");
		
		else if(no/no==-1)
		printf("This is a negetive number");
		
		else 
		peintf("This is a zeros number");
	}
}
//Q-7
a#include<stdio.h>
void main()
{ 
    int no,count;
	count=1;
	while(count+=5)
	{
		printf("Enter the numbers of your choice");
	    scanf("%d",&no);
	
		if(no==0)
		printf("This is a zero number");
		
		else if(no>0)
		printf("This is a positive number");
		
		else if(no<0)
		printf("This is a negetive number");
	}
	
}

