//Ex-B
//Q-1
/*#include<stdio.h>
int main()
{
	int suite=1;
	switch(suite)
	{
		case 0:
		printf("Club\n");
		case 1:
		printf("dimond\n");
	}
	return 0;
}
//Q-2
#include <stdio.h>
void  main()
{
	int temp;
	printf("Enter the temp");
	scanf("%d",&temp);
	switch(temp)
	{
		case 20:
		printf("ABCD");
		break;
		case 30:
		printf("DEFG");
		break;
		default:
		printf("HIJK");
		break;
	}
}*/
#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter the value of a and b");
	scanf("%d%d",&a,&b);
	c=b-a;
	switch(c)
	{
		case 0:
		printf("Go to HELL with Hell Boy");
		break;
		case 3:
		printf("Go to HELL without Hell Boy");
		break;
		default:
		printf("Stay in HELL");
		break;
	}
	return 0;
}
/*/Ex-D
#include <stdio.h>
void main()
{
	int cls,fls;
	printf("Enter the class you got=");
	scanf("%d",&cls);
	switch(cls)
	{
		case 3:
        printf("you will get 15 grace marks");
        case 2:
		printf("you will get 10 grace marks");
		case 3:
		printf("You will get 5 grace marks");
	}
}
	*/