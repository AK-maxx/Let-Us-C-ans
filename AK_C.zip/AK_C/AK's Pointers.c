//Q-1
#include <stdio.h>
int main()
{
    int m=10,n,o, *z;
    z=&m;
    printf("Value of m=%d\n", *z);
    printf("Value of m=%d\n",m);
    printf("Value of z=%d\n",z);
    printf("Address of m=%u\n",z);
    printf("Address of m=%u\n",&m);
    printf("Address of z=%u\n",&z);
    return 0;
}
//Q-3
#include <stdio.h>
int main()
{
    int a=12, *b;
    b=&a;
    printf("address of a=%u\n",&a);
    printf("address of a=%u\n",b);
    printf("value of a=%d\n",a);
    printf("value of a=%d\n", *b);
    return 0;

}
//Q-4
#include <stdio.h>
int main()
{
    int a=2,b=2, *aa, *bb,sum;
    aa=&a;
    bb=&b;
    sum= *aa+ *bb;
    printf("The sum of value a and b=%d\n",sum);
    return 0;
}
//Q-5
#include <stdio.h>
int cal(int *a,int *b)
{
    int *sum;
    sum= *a+ *b;
    return sum;
}
int main()
{
    int sum,a,b;
    printf("Enter the value of a:");
    scanf("%d\n",&a);
    printf("Enter the value of b:");
    scanf("%d\n",&b);
    sum=cal(&a,&b);
    printf("The sum of a and b is=%d\n",sum);
    return 0;
}
//Q-6
#include <stdio.h>
int main()
{
    int *z, *x;
    int a,b;

    printf("Enter first number");
    scanf("%d\n",&a);
    printf("Enter second number");
    scanf("%d\n",&b);
    printf("\n");
    z=&a; x=&b;
    if(z<x)
        printf("First number is greater");
    else
        printf("Second number is greater");

    return 0;
}
//Q-7
#include <stdio.h>
int main()
{
    int a[10];
    int i,j;

    printf("enter the 10 elements you want to store");
    for(i=0;i<=10;i++)
    {
        scanf("%d\n",a+i);
    }
    for (j=0;j<=10;j++)
        printf("the elements are=%d\n", *(a+j));

    return 0;
} */
//Q-9
#include <stdio.h>
void func(int *n1,int *n2,int *n3)
{
    int i= *n1;
    *n1= *n2;
    *n2= *n3;
    *n3= i;

}
int main()
{
    int n1,n2,n3;

    printf("Enter the number n1");
    scanf("%d\n",&n1);
    printf("Enter the number n2");
    scanf("%d\n",&n2);
    printf("Enter the number n3");
    scanf("%d\n",&n3);

    func(&n1,&n2,&n3);

    printf("The elements were:\n");
    printf("%d\n%d\n%d\n",n1,n2,n3);

    return 0;

}
