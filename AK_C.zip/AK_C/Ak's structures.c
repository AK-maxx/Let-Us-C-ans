#include <stdio.h>
struct book
{
    char name[50];
    char aut[50];
    int pages;
    int price;
}b[5];
int main()
{
    int i;

    for(i=0;i<5;i++)
    {
        printf("Enter the name of book:");
        gets(b[i].name);
        printf("Enter the author name:");
        gets(b[i].aut);
        printf("Enter the number of pages:");
        scanf("%d\n",&b[i].pages);
        scanf("Enter the price of the book:");
        scanf("%d\n",&b[i].price);
    }
    for(i=0;i<5;i++)
    {
        printf("Enter the name of book:%s\n",b[i].name);
        printf("Enter the author name:%s\n",b[i].aut);
        printf("Enter the number of pages:%s\n",b[i].pages);
        scanf("Enter the price of the book:%s\n",b[i].price);
    }
    return 0;
}
