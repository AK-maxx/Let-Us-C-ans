#include <stdio.h>
int hertz(int,int,float);
void main()
{
    int r1,r2;
    float c1,hz;

    printf("Enter the value of R1 in ohm=");
    scanf("%d\n",&r1);
    printf("Enter the value of R2 in ohm=");
    scanf("%d\n",&r2);
    printf("Enter the value of C1 in fered=");
    scanf("%f\n",&c1);

    hz=hertz(r1,r2,c1);
    printf("\n");
    printf("The Frequency of your 555 timer is=%fHz\n",hz);
}
int hertz(int r1,int r2,float c1)
{
    int hz;
    hz= 1.44/( r1+ (2*r2))*c1;

    return ( hz);
}
