/*
//Q-1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void num(int n)
{
    if(n<=50)
    {
        num(n+1);
        printf("%d ",n);
    }
}
void main()
{
    int no=1;
    printf("The first 50 natural numbers are:");
    num(no);
}
**
//Q-2
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int sum(int n)
{
   int res;
   if (n==1)
   {
      return (1);
   } else
   {
      res=n+sum(n-1);
   }
   return (res);
}

void main()
{
   int n;

   printf(" Enter the number from 1 : ");
   scanf("%d", &n);

   int res = sum(n);
   printf("Sum: %d\n",sum);
}

//Q-8
#include <stdio.h>
#include <stdlib.h>
int display(int arr[],int i,int len)
{
    if(i>=len)
    {
        return 10;
    }
    else
    {
        int a=display(arr,i++,len);
        return (a);
    }
}
int main()
{
    int arr[5]={1,2,3,4,5};
    int num=display(arr,0,5);
    if(num==10)
    {
        printf("Done!");
        exit(6);
    }
    else
    {
        printf("%d ",num);
    }
    return 0;
}

//Q-9
#include <stdio.h>
#include <stdlib.h>
int display(char str[],int l)
{
    if(l<0)
        return 10;
    else
    {
        char ch=str[l];
        display(str,l-1);
    }
    return ch;
}
void main()
{
    char str[]="hsakA";
    char ch=display(str,4);
    printf("%c",ch);
}
*/
//Q-19
#include <stdio.h>
#include <stlib.h>
void copy(char str1,char str2)
{

}
void main()
{
    char str1[5]="Akash";
    char str2[];
    copr
}

