#include <stdio.h>
#include <string.h>
int main()
{
    char stg[]={}
    int (*ptr)[5];

    ptr=arr;
    printf("The first value of the array=%d");

    return 0;
}
