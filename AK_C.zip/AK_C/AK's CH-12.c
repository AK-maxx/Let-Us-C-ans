//rough practice
//P of macro expansion
//1
#include <stdio.h>
#define SUM 75
int main()
{
    int r;
    printf("Enter the ruppees to be expressed in dollar=");
    scanf("%d\n",&r);
    r2=r/SUM;

    printf("�%d into dollar=$%d",r,r2);
    return 0;

}
//2
#include <stdio.h>
#define SUM(r) (r/75)
int main()
{
    int r;
    printf("Enter the first number=");
    scanf("%d\n",&r);

    printf("�%d into dollar=$%d",r,SUM(r));
    return 0;

}
//P of file inclusion
//1
#include <stdio.h>
#include "rect.h"
int main()
{
    int l,b;
    printf("Enter the lenght of the rectangle");
    scanf("%d\n", &l);
    printf("Enter the breadth of the rectangle");
    scanf("%d\n", &b);

    printf("The area of the circle is=%d\n", rect(&l,&b));
    return 0;
}
//2
#include <stdio.h>
#include "rect.h"
int main()
{
    int l,b;
    printf("Enter the lenght of the rectangle");
    scanf("%d\n", &l);
    printf("Enter the breadth of the rectangle");
    scanf("%d\n", &b);

    printf("The area of the circle is=%d\n", rect(r));
    return 0;
}
//P for Conditional compilation
#include <stdio.h>
#define WAS
int main()
{
    #if WAS
        printf("And this was");
    #else
        printf("And this is");

    #endif
    return 0;
}
//P for Miscellaneous Directives
//Undef
#include <stdio.h>
#define WAS
#undef WAS
int main()
{
    #ifdef WAS
        printf("....And this was");
    #else
        printf("....And this is");

    #endif
    return 0;
}
//Pragma
#include <stdio.h>
#pragma warn -rvl
#pragma warn -par
#pragma warn -rch
int cal(int,int);
int fun();
int main()
{
    fun();
    f2(6);
    f3();
    int a=5,b=5;
    printf("The sum of a and b is=%d\n",cal(a,b));
    return 0;
}
int cal(int a,int b)
{
    return (a+b);
}
int fun()
{
    int a=5;
}
void f2(int a)
{
    printf("This is f2");
}
int f3()
{
    int a=6;
    return a;
    a++;
}

